// Пример интерактивности для кнопки "Начать задание"
document.getElementById('start-task').addEventListener('click', function() {
  alert('Задание начато! Создайте свой интерфейс.');
});
